
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "10.3.0"

#define NTL_MAJOR_VERSION  (10)
#define NTL_MINOR_VERSION  (3)
#define NTL_REVISION       (0)

#endif

